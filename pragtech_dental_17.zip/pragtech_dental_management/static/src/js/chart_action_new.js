/** @odoo-module **/

import { Component, useState ,onMounted} from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useBus, useService } from "@web/core/utils/hooks";
import { standardFieldProps } from "@web/views/fields/standard_field_props";


export class DentalChartAction extends Component {
    static props = { ...standardFieldProps };
    setup() {

        this.context = useState(this.props.action.context);
        super.setup();
        this.actionService = useService("action");
        this.orm = useService("orm");
        this.rpc = useService('rpc');
        onMounted(this.onMounted);
    }

    onMounted() {
        this.get_treatment_cats()
        this.patient_history()
        this.renderElement()
        // this.writePatientHistory()
        console.log("--------called onMounted method-------",this.props.action)
        const type = this.props.action.params.type;
        console.log("--------called onMounted method-------", type);

    }

    // incrementThread(selectedSurf) {
    //     selectedSurf.forEach(ss => {
    //         const prevCnt = document.getElementById(ss).classList[3];
    //         const newCnt = String(parseInt(prevCnt) + 1);
    //         document.getElementById(ss).classList.remove(prevCnt);
    //         document.getElementById(ss).classList.add(newCnt);
    //     });
    // }

    
    async patient_history() {
        var Missing_Tooth = 0;
        var NO_OF_TEETH = 32;
        var cnt = 1;
        var cnt2 = 1;
        var surface2_cnt = 32;
        var tooth2_cnt = 32;
        var Palmer;
        var Iso;
        var type = '';
        var self = this;

        type = 'palmer';

        if (type == 'palmer') {
            var palmer = {
                '1' : '8-1x',
                '2' : '7-1x',
                '3' : '6-1x',
                '4' : '5-1x',
                '5' : '4-1x',
                '6' : '3-1x',
                '7' : '2-1x',
                '8' : '1-1x',
                '9' : '1-2x',
                '10' : '2-2x',
                '11' : '3-2x',
                '12' : '4-2x',
                '13' : '5-2x',
                '14' : '6-2x',
                '15' : '7-2x',
                '16' : '8-2x',
                '17' : '8-3x',
                '18' : '7-3x',
                '19' : '6-3x',
                '20' : '5-3x',
                '21' : '4-3x',
                '22' : '3-3x',
                '23' : '2-3x',
                '24' : '1-3x',
                '25' : '1-4x',
                '26' : '2-4x',
                '27' : '3-4x',
                '28' : '4-4x',
                '29' : '5-4x',
                '30' : '6-4x',
                '31' : '7-4x',
                '32' : '8-4x',

            };
            Palmer = palmer;
        }

        if (type == 'iso') {
            var iso = {
                '1' : '18',
                '2' : '17',
                '3' : '16',
                '4' : '15',
                '5' : '14',
                '6' : '13',
                '7' : '12',
                '8' : '11',
                '9' : '21',
                '10' : '22',
                '11' : '23',
                '12' : '24',
                '13' : '25',
                '14' : '26',
                '15' : '27',
                '16' : '28',
                '17' : '38',
                '18' : '37',
                '19' : '36',
                '20' : '35',
                '21' : '34',
                '22' : '33',
                '23' : '32',
                '24' : '31',
                '25' : '41',
                '26' : '42',
                '27' : '43',
                '28' : '44',
                '29' : '45',
                '30' : '46',
                '31' : '47',
                '32' : '48',
            };
            Iso = iso;
        }

        for (var t = 1; t <= NO_OF_TEETH; t++) {
            var NS = 'http://www.w3.org/2000/svg';
            var svg = $('#svg_object')[0];
            console.log('svgsvg ',svg)
            if (cnt <= 16) {//devided teeths into 2 sections
                var path1_1 = 34.95833333333337;
                var path1_2 = 21.250000000000007;
                var path2_1 = 25.513888888888914;
                var path2_2 = 31.875000000000007;
                var path3_1 = 34.95833333333337;
                var path3_2 = 46.04166666666665;
                var path4_1 = 52.666666666666686;
                var path4_2 = 31.875000000000007;
                var path5_1 = 34.958333333333385;
                var path5_2 = 31.875000000000007;

                var source_img = '<img class = "teeth" src = "/pragtech_dental_management/static/src/img/tooth' + t + '.png" id = ' + t + ' width = "46" height = "50"/>';
                var missing = 0;
                for (var m = 0; m < Missing_Tooth.length; m++) {
                    if (t == Missing_Tooth[m]) {
                        missing = 1;
                        // var source_img = '<img class = "blank" src = "/pragtech_dental_management/static/src/img/images.png" id = ' + t + ' width = "46" height = "50"/>';
                        var source_img = '<img class = "blank" src = "/pragtech_dental_management/static/src/img/tooth' + t + '.png" id = ' + t + ' width = "46" height = "50" style="visibility:hidden"/>';
                    }
                }
                $("#teeth-surface-1").append(source_img);
                if (cnt == 1) {//hardcode first rectangular coordinates
                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view buccal " + cnt + '_buccal 0');
                    newElement.setAttribute("id", "view_" + cnt + "_top");

                    newElement.setAttribute("d", "M0 0 L17.708333333333314 0 L17.708333333333314 10.625 L0 10.625 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + path1_1 + " " + path1_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("d", "M0 0 L9.444444444444457 0 L9.444444444444457 14.166666666666657 L0 14.166666666666657 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + path2_1 + " " + path2_2 + ")");
                    newElement.setAttribute("class", "view distal " + cnt + '_distal 0');
                    newElement.setAttribute("id", "view_" + cnt + "_left");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view lingual " + cnt + '_lingual 0');
                    newElement.setAttribute("id", "view_" + cnt + "_bottom");
                    newElement.setAttribute("d", "M0 0 L17.708333333333314 0 L17.708333333333314 10.625 L0 10.625 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + path3_1 + " " + path3_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view mesial " + cnt + '_mesial 0');
                    newElement.setAttribute("id", "view_" + cnt + "_right");
                    newElement.setAttribute("d", "M0 0 L8.263888888888914 0 L8.263888888888914 14.166666666666657 L0 14.166666666666657 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + path4_1 + " " + path4_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view occlusal " + cnt + '_occlusal 0');
                    newElement.setAttribute("id", "view_" + cnt + "_center");
                    newElement.setAttribute("d", "M0 0 L17.7083333333333 0 L17.7083333333333 14.166666666666629 L0 14.166666666666629 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + path5_1 + " " + path5_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                } else {
                    var top,
                        bottom,
                        right,
                        left,
                        center;
                    if (cnt <= 5) {
                        top = 'buccal';
                        right = 'mesial';
                        bottom = 'lingual';
                        left = 'distal';
                        center = 'occlusal';
                    } else if (cnt <= 11) {
                        top = 'labial';
                        right = 'mesial';
                        bottom = 'lingual';
                        left = 'distal';
                        center = 'incisal';
                    } else if (cnt <= 16) {
                        top = 'buccal';
                        right = 'distal';
                        bottom = 'lingual';
                        left = 'mesial';
                        center = 'occlusal';
                    }
                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view " + top + " " + cnt + '_' + top + ' 0');
                    newElement.setAttribute("id", "view_" + cnt + "_top");
                    newElement.setAttribute("d", "M0 0 L17.708333333333314 0 L17.708333333333314 10.625 L0 10.625 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + (path1_1 + (46 * (cnt - 1))) + " " + path1_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view " + left + " " + cnt + '_' + left + ' 0');
                    newElement.setAttribute("id", "view_" + cnt + "_left");
                    newElement.setAttribute("d", "M0 0 L9.444444444444457 0 L9.444444444444457 14.166666666666657 L0 14.166666666666657 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + (path2_1 + (46 * (cnt - 1))) + " " + path2_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);


                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view " + bottom + " " + cnt + '_' + bottom + ' 0');
                    newElement.setAttribute("id", "view_" + cnt + "_bottom");
                    newElement.setAttribute("d", "M0 0 L17.708333333333314 0 L17.708333333333314 10.625 L0 10.625 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + (path3_1 + (46 * (cnt - 1))) + " " + path3_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view " + right + " " + cnt + '_' + right + ' 0');
                    newElement.setAttribute("id", "view_" + cnt + "_right");
                    newElement.setAttribute("d", "M0 0 L8.263888888888914 0 L8.263888888888914 14.166666666666657 L0 14.166666666666657 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + (path4_1 + (46 * (cnt - 1))) + " " + path4_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view " + center + " " + cnt + '_' + center + ' 0');
                    newElement.setAttribute("id", "view_" + cnt + "_center");
                    newElement.setAttribute("d", "M0 0 L17.7083333333333 0 L17.7083333333333 14.166666666666629 L0 14.166666666666629 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + (path1_1 + (46 * (cnt - 1))) + " " + path4_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                }
                if (missing) {
                    $("#view_" + cnt + "_top,#view_" + cnt + "_left,#view_" + cnt + "_bottom,#view_" + cnt + "_right,#view_" + cnt + "_center").attr('visibility', 'hidden');
                }
            }else {
                var p1_1 = 33.998659373659635;
                var p1_2 = 69.01321857571864;
                var p2_1 = 24.554214929215078;
                var p2_2 = 79.63821857571861;
                var p3_1 = 33.998659373659635;
                var p3_2 = 93.80488524238524;
                var p4_1 = 51.706992706992764;
                var p4_2 = 79.63821857571861;

                var source_img = '<img class = "teeth" src = "/pragtech_dental_management/static/src/img/tooth' + tooth2_cnt + '.png" id = ' + tooth2_cnt + ' width = "46" height = "50"/>';

                var missing = 0;
                for (var m = 0; m < Missing_Tooth.length; m++) {
                    if (tooth2_cnt == Missing_Tooth[m]) {
                        missing = 1;
                        // var source_img = '<img class = "blank" src = "/pragtech_dental_management/static/src/img/images.png" id = ' + tooth2_cnt + ' width = "46" height = "50"/>';
                        var source_img = '<img class = "blank" src = "/pragtech_dental_management/static/src/img/tooth' + tooth2_cnt + '.png" id = ' + tooth2_cnt + ' width = "46" height = "50" style="visibility:hidden"/>';
                    }
                }
                $("#teeth-surface-2").append(source_img);
                if (cnt == 17) {//hardcode first rectangular coordinates
                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view lingual " + surface2_cnt + '_lingual 0');
                    newElement.setAttribute("id", "view_" + surface2_cnt + "_top");
                    newElement.setAttribute("d", "M0 0 L17.708333333333314 0 L17.708333333333314 10.625 L0 10.625 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + p1_1 + " " + p1_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view distal " + surface2_cnt + '_distal 0');
                    newElement.setAttribute("id", "view_" + surface2_cnt + "_left");
                    newElement.setAttribute("d", "M0 0 L9.444444444444457 0 L9.444444444444457 14.166666666666657 L0 14.166666666666657 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + p2_1 + " " + p2_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view buccal " + surface2_cnt + '_buccal 0');
                    newElement.setAttribute("id", "view_" + surface2_cnt + "_bottom");
                    newElement.setAttribute("d", "M0 0 L17.708333333333314 0 L17.708333333333314 10.625 L0 10.625 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + p3_1 + " " + p3_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view mesial " + surface2_cnt + '_mesial 0');
                    newElement.setAttribute("id", "view_" + surface2_cnt + "_right");
                    newElement.setAttribute("d", "M0 0 L8.263888888888914 0 L8.263888888888914 14.166666666666657 L0 14.166666666666657 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + p4_1 + " " + p4_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view occlusal " + surface2_cnt + '_occlusal 0');
                    newElement.setAttribute("id", "view_" + surface2_cnt + "_center");
                    newElement.setAttribute("d", "M0 0 L17.7083333333333 0 L17.7083333333333 14.166666666666629 L0 14.166666666666629 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + p1_1 + " " + p4_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                } else {
                    var top,
                        bottom,
                        right,
                        left,
                        center;
                    if (surface2_cnt <= 21) {
                        top = 'lingual';
                        right = 'distal';
                        bottom = 'buccal';
                        left = 'mesial';
                        center = 'occlusal';
                    } else if (surface2_cnt <= 27) {
                        top = 'lingual';
                        right = 'mesial';
                        bottom = 'labial';
                        left = 'distal';
                        center = 'incisal';
                    } else {
                        top = 'lingual';
                        right = 'mesial';
                        bottom = 'buccal';
                        left = 'distal';
                        center = 'occlusal';
                    }
                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view " + top + " " + surface2_cnt + "_" + top + ' 0');
                    newElement.setAttribute("id", "view_" + surface2_cnt + "_top");
                    newElement.setAttribute("d", "M0 0 L17.708333333333314 0 L17.708333333333314 10.625 L0 10.625 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + ((path1_1 + (46 * (cnt2 - 1)) - 1)) + " " + p1_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view " + left + " " + surface2_cnt + "_" + left + ' 0');
                    newElement.setAttribute("id", "view_" + surface2_cnt + "_left");
                    newElement.setAttribute("d", "M0 0 L9.444444444444457 0 L9.444444444444457 14.166666666666657 L0 14.166666666666657 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + ((path2_1 + (46 * (cnt2 - 1)) - 1)) + " " + p2_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);


                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view " + bottom + " " + surface2_cnt + "_" + bottom + ' 0');
                    newElement.setAttribute("id", "view_" + surface2_cnt + "_bottom");
                    newElement.setAttribute("d", "M0 0 L17.708333333333314 0 L17.708333333333314 10.625 L0 10.625 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + ((path3_1 + (46 * (cnt2 - 1)) - 1)) + " " + p3_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);


                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view " + right + " " + surface2_cnt + "_" + right + ' 0');
                    newElement.setAttribute("id", "view_" + surface2_cnt + "_right");
                    newElement.setAttribute("d", "M0 0 L8.263888888888914 0 L8.263888888888914 14.166666666666657 L0 14.166666666666657 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + ((path4_1 + (46 * (cnt2 - 1)) - 1)) + " " + p4_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                    var newElement = document.createElementNS("http://www.w3.org/2000/svg", 'path');
                    newElement.setAttribute("class", "view " + center + " " + surface2_cnt + "_" + center + ' 0');
                    newElement.setAttribute("id", "view_" + surface2_cnt + "_center");
                    newElement.setAttribute("d", "M0 0 L17.7083333333333 0 L17.7083333333333 14.166666666666629 L0 14.166666666666629 L0 0 Z");
                    newElement.setAttribute("transform", "matrix(1 0 0 1 " + ((path1_1 + (46 * (cnt2 - 1)) - 1)) + " " + p4_2 + ")");
                    newElement.setAttribute("fill", "white");
                    newElement.setAttribute("stroke", "black");
                    svg.appendChild(newElement);

                }
                if (missing) {
                    $("#view_" + surface2_cnt + "_top,#view_" + surface2_cnt + "_left,#view_" + surface2_cnt + "_bottom,#view_" + surface2_cnt + "_right,#view_" + surface2_cnt + "_center").attr('visibility', 'hidden');
                }
                surface2_cnt -= 1;
                tooth2_cnt -= 1;
                cnt2++;
            }
            cnt++;

        }

        var other_patient_history = new Array();
        other_patient_history.forEach(function(each_operation) {
            if (each_operation.tooth_id)
                self.color_surfaces(svg, each_operation['surface'].split(' '), each_operation['tooth_id'], self);
            else {
                self.add_selection_action(each_operation['multiple_teeth']);
                each_operation.tooth_id = '-';
                if (each_operation['desc']['action'] == 'missing') {
                    self.perform_missing_action(each_operation['multiple_teeth']);
                }
            }
        });

        $("img").click(function() {
            var selected_treatment = '';
            console.log("--------called img click method-------",this)
            if (!selected_treatment) {
                if ($(this).attr('class') == 'selected_tooth') {
                    $(this).removeClass('selected_tooth');
                    self.decrement_thread(['view_' + this.id + '_bottom', 'view_' + this.id + '_center', 'view_' + this.id + '_right', 'view_' + this.id + '_left', 'view_' + this.id + '_top']);
                    if (document.getElementById('view_' + this.id + '_center').classList[3] == "0")
                        $('#view_' + this.id + '_center').attr('fill', 'white');
                    if (document.getElementById('view_' + this.id + '_right').classList[3] == "0")
                        $('#view_' + this.id + '_right').attr('fill', 'white');
                    if (document.getElementById('view_' + this.id + '_left').classList[3] == "0")
                        $('#view_' + this.id + '_left').attr('fill', 'white');
                    $('#view_' + this.id + '_top').attr('fill', 'white');
                    $('#view_' + this.id + '_bottom').attr('fill', 'white');
                    selected_surface.length = 0;
                } else {
                    $(this).attr('class', 'selected_tooth');
                    $('#view_' + this.id + '_center').attr('fill', 'orange');
                    $('#view_' + this.id + '_right').attr('fill', 'orange');
                    $('#view_' + this.id + '_left').attr('fill', 'orange');
                    $('#view_' + this.id + '_top').attr('fill', 'orange');
                    $('#view_' + this.id + '_bottom').attr('fill', 'orange');
                    self.increment_thread(['view_' + this.id + '_bottom', 'view_' + this.id + '_center', 'view_' + this.id + '_right', 'view_' + this.id + '_left', 'view_' + this.id + '_top']);
                }
                return;
            }
            console.log("--------selected_treatment-------",selected_treatment)
            selected_tooth = this.id;
            console.log("--------selected_tooth-------",selected_tooth)
            self.execute_create(false, self, false);

            switch(selected_treatment.action) {
            case 'missing':
                if ($("#" + $(this).attr('id')).attr('class') == "teeth") {
                    // $($("#" + $(this).attr('id')).attr('src', "/pragtech_dental_management/static/src/img/images.png").attr('class', 'blank'));
                    $($("#" + $(this).attr('id')).attr('class', 'blank'));
                    $($("#" + $(this).attr('id'))).css('visibility', 'hidden');
                    $("#view_" + $(this).attr('id') + "_top,#view_" + $(this).attr('id') + "_left,#view_" + $(this).attr('id') + "_bottom,#view_" + $(this).attr('id') + "_right,#view_" + $(this).attr('id') + "_center").attr('visibility', 'hidden');
                } else {
                    $($("#" + $(this).attr('id')).css('visibility', 'visible').attr('class', 'teeth'));
                    $("#view_" + $(this).attr('id') + "_top,#view_" + $(this).attr('id') + "_left,#view_" + $(this).attr('id') + "_bottom,#view_" + $(this).attr('id') + "_right,#view_" + $(this).attr('id') + "_center").attr('visibility', 'visible');
                    for (var op_id = 1; op_id <= operation_id; op_id++) {
                        if ($('#operation_'+op_id)[0]) {
                            var got_op_id = ($('#operation_'+op_id)[0].id).substr(10);
                            if (parseInt($('#tooth_'+got_op_id)[0].innerHTML) == parseInt(this.id)){

                                var tr = document.getElementById('operation_' + got_op_id);
                                var desc_class = $("#desc_" + got_op_id).attr('class');
                                tr.parentNode.removeChild(tr);
                                for (var index = 0; index < treatment_lines.length; index++) {
                                    if (treatment_lines[index].teeth_id == this.id) {
                                        for (var i2 = 0; i2 < treatment_lines[index].values.length; i2++) {
                                            if (treatment_lines[index].values[i2].categ_id == parseInt(desc_class)) {
                                                treatment_lines.splice(index, 1);
                                                operation_id += 1;
                                                return;
                                            }
                                        }
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
                break;
            case 'composite':
                break;
            default :
                break;
            };

        });

        $(".view").click(function() {
            var self = this;
            var cont = true;
            var is_tooth_select = false
            var update = false;
            var selected_surface = [];
            var selected_tooth = '';

            if (!cont || update) {
                selected_surface.length = 0;
                cont = true;
            } else {
                if (selected_surface[0]) {
                    var tooth = (selected_surface[0].split('_'))[1];
                    var current_tooth = ((this.id).split('_'))[1];
                    if (current_tooth != tooth) {
                        for (var i = 0; i < selected_surface.length; i++) {
                            $("#" + selected_surface[i]).attr('fill', 'white');
                        }
                        selected_surface.length = 0;
                    }
                }
            }
            var found_selected_operation = $(self).find('.selected_operation');
            // var found_selected_operation = this.$el.find('.selected_operation');
            console.log("=================found_selected_operation===========",found_selected_operation)
            if (found_selected_operation[0]) {
                var op_id = ((found_selected_operation[0].id).split('_'))[1];
                if ($('#status_' + op_id)[0].innerHTML == 'Completed'){
                    alert('Cannot update Completed record');
                    $('#operation_' + op_id).removeClass('selected_operation');
                    return;
                }
                var s = (($("#" + this.id).attr('class')).split(' '))[1];
                if (((this.id).split('_'))[1] == $('#tooth_' + op_id).attr('class')) {
                    update = true;
                    var surf_old_list = ($('#surface_'+op_id)[0].innerHTML).split(' ');
                    var got = 0;
                    for (var in_list = 0; in_list < surf_old_list.length; in_list++) {
                        if (surf_old_list[in_list] == s) {
                            got = 1;
                            var index = selected_surface.indexOf(this.id);
                            selected_surface.splice(index, 1);
                            $('#surface_' + op_id).empty();
                            surf_old_list.forEach(function(sol) {
                            // _.each(surf_old_list, function(sol) {
                                if (sol != s)
                                    $('#surface_'+op_id)[0].innerHTML += sol + ' ';
                            });
                            self.decrement_thread([this.id]);
                            break;
                        }
                    }
                    if (got == 0) {
                        $('#surface_'+op_id)[0].innerHTML += s + ' ';
                        selected_surface.push(this.id);
                        self.increment_thread([this.id]);
                    }
                } else {
                    update = false;
                }
            }
            selected_tooth = ((this.id).split('_'))[1];
            if (1) {
                if ($("#" + $(this).attr('id')).attr('fill') == 'white') {
                    $("#" + $(this).attr('id')).attr('fill', 'orange');
                    var available = selected_surface.indexOf(this.id);
                    if(available == -1 && is_tooth_select == false){

                        selected_surface.push(this.id);
                    }

                } else if (parseInt(($("#" + $(this).attr('id')).attr('class')).split(' ')[3]) == 0){
                    is_tooth_select = false
                    $("#" + $(this).attr('id')).attr('fill', 'white');
                    var index = selected_surface.indexOf(this.id);
                    selected_surface.splice(index, 1);
                } else {
                    console.log("-------**-    ",$("#" + $(this).attr('id')).attr('fill'))
//
                    if ($("#" + $(this).attr('id')).attr('fill') == 'orange') {
                    $("#" + $(this).attr('id')).attr('fill', 'white');
                    is_tooth_select = true
                    var current_tooth_id = this.id.lastIndexOf("_")
                    var res = this.id.slice(current_tooth_id, this.id.length);

                    }
                    else{
                        selected_surface.push(this.id);

                    }
                }
            console.log("-------**-    ",selected_surface)
            }
        });


    }


    async renderElement() {
        const self = this;
    
        try {
            const res = await this.orm.call('teeth.code', 'get_teeth_code', [this.props.action.params.patient_id], {})
            
            var name = "";
            var j = 0;
            var k = 7;
            var l = 0;
            var type = this.props.action.params.type;
    
            if (type === 'universal') {
                for (var i = 0; i < 16; i++) {
                    name = `<td width="46px" id="teeth_${i}">${res[i]}</td>`;
                    $('#upper_teeths').append(name);
                }
                for (var i = 31; i > 15; i--) {
                    name = `<td width="46px" id="teeth_${i}">${res[i]}</td>`;
                    $('#lower_teeths').append(name);
                }
            } else if (type === 'palmer') {
                for (var i = 7; i >= 0; i--) {
                    name = `<td width="47px" id="teeth_${i}">${res[i]}</td>`;
                    $('#upper_teeths').append(name);
                }
                for (var i = 7; i < 15; i++) {
                    name = `<td width="47px" id="teeth_${i}">${res[j]}</td>`;
                    $('#upper_teeths').append(name);
                    j++;
                }
                for (var i = 23; i > 15; i--) {
                    name = `<td width="47px" id="teeth_${i}">${res[k]}</td>`;
                    $('#lower_teeths').append(name);
                    k--;
                }
                for (var i = 24; i < 32; i++) {
                    name = `<td width="47px" id="teeth_${i}">${res[l]}</td>`;
                    $('#lower_teeths').append(name);
                    l++;
                }
            } else if (type === 'iso') {
                for (var i = 0; i <= 7; i++) {
                    name = `<td width="46px" id="teeth_${i}">${res[i]}</td>`;
                    $('#upper_teeths').append(name);
                }
                for (var i = 8; i <= 15; i++) {
                    name = `<td width="46px" id="teeth_${i}">${res[i]}</td>`;
                    $('#upper_teeths').append(name);
                }
                for (var i = 31; i >= 24; i--) {
                    name = `<td width="46px" id="teeth_${i}">${res[i]}</td>`;
                    $('#lower_teeths').append(name);
                }
                for (var i = 23; i >= 16; i--) {
                    name = `<td width="46px" id="teeth_${i}">${res[i]}</td>`;
                    $('#lower_teeths').append(name);
                }
            }
        } catch (error) {
            console.error('An error occurred:', error);
        }
    }
    



    

    async get_treatment_cats() {
        console.log("........................getTreatmentCategories executed1...............");
        const self = this;
        var full_mouth_selected = 0;
        var is_tooth_select = false
        var cont = true;

        try {
            const res = await this.orm.call('product.category', 'get_treatment_categs', [this.props.action.params.patient_id], {})
            const treatment_list = res;
            let total_list_div = '';
            console.log("getTreatmentCategories executed");

            for (let j = 0; j < treatment_list.length; j++) {
                total_list_div += `
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a id="categ_${treatment_list[j].treatment_categ_id}" data-bs-toggle="collapse" href="#collapse${treatment_list[j].treatment_categ_id}">
                                ${treatment_list[j].name}
                            </a>
                        </h4>
                    </div>`;

                total_list_div += `<div id="collapse${treatment_list[j].treatment_categ_id}" class="collapse">
                    <div class="panel-body">`;

                treatment_list[j].treatments.forEach(each_one => {
                    if (each_one.action == 'missing') {
                        missing = each_one.treatment_id;
                    }

                    total_list_div += `
                        <li id="treat_${treatment_list[j].treatment_categ_id}_${each_one['treatment_id']}">
                            ${each_one['treatment_name']}
                        </li>`;
                });

                total_list_div += `</div></div>`;
            }

            $('#total_list_div').append(total_list_div);
            self.categ_list = treatment_list;
            var selected_category = '';

            for (let i = 0; i < self.categ_list.length; i++) {
                $('#categ_' + self.categ_list[i].treatment_categ_id).click(function() {
                    var selected_surface = ['view_4_center'];
                    console.log("selected_surface", selected_surface)
                    if (selected_surface) {
                        console.log("Inside selected surface condition")
                        var found_selected_categ = $(self).find('.selected_category');
                        if (found_selected_categ) {
                            found_selected_categ.removeClass("selected_category");
                        }
                        var selected_treatment = '';
                        $('#' + this.id).attr('class', 'selected_category');
                        var categ_no = parseInt(this.id.substr(6));
                        $('#treatments_list').empty();
                        // self.$('#treatments_list').empty();
                        for (var k = 0; k < self.categ_list.length; k++) {
                            console.log("self.categ_list[k].treatment_categ_id", self.categ_list[k].treatment_categ_id)
                            console.log("categ_no", categ_no)
                            if (self.categ_list[k].treatment_categ_id == categ_no) {
                                console.log("Inside If")
                                self.categ_list[k].treatments.forEach(function(each_treatment) {
                                // _.each(self.categ_list[k].treatments, function(each_treatment) {
                                    console.log("Inside each function")
                                    $('#treat_' + categ_no + '_' + each_treatment.treatment_id).attr('data-selected', 'false');
                                    $('#treat_' + categ_no + '_' + each_treatment.treatment_id).click(function() {
                                        console.log("Inside treatment function")
                                        if (full_mouth_selected == 1) {
                                            self.put_data_full_mouth(self, full_mouth_teeth, full_mouth_selected, each_treatment, false, false, false, false);
                                            return;
                                        }
                                        cont = false;
                                        var found_selected_tooth = $(self).find('.selected_tooth');
                                        console.log("found_selected_tooth", found_selected_tooth)
                                        if (found_selected_tooth[0]) {
                                            console.log("Inside found_selected_tooth")
                                            selected_surface.length = 0;
                                        }
                                        var is_tooth_select = false
                                        console.log("selected_surface", selected_surface)
                                        console.log("selected_surface.lengthhhhhhhhh", is_tooth_select)
                                        if (selected_surface[0]) {
                                            if(each_treatment.action != 'missing'){
                                                console.log("Inside selected_surface[0]")
                                                var found = $(self).find('.selected_treatment');
                                                if (found) {
                                                    found.removeClass("selected_treatment");
                                                }
                                                $('#treat_' + categ_no + '_' + each_treatment.treatment_id).attr('class', 'selected_treatment');
                                                selected_treatment = each_treatment;
                                                self.execute_create(true, self, selected_surface);
                                            }
                                            else{
                                                var answer = confirm('Complete tooth has to be missing, not the selected surfaces.\nClick OK to remove the complete tooth')
                                                if(answer){
                                                    var tooth_id = selected_surface[0].split('_')[1]
                                                    console.log("toothhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh")
                                                    $('#'+tooth_id).attr('class','selected_tooth')
                                                    found_selected_tooth = $(self).find('.selected_tooth');
                                                }
                                            }
                                        }

                                        if (found_selected_tooth[0]) {
                                            if (!found_selected_tooth[0])
                                                alert('Please select the surface first!');
                                            else {
                                                var found = $(self).find('.selected_treatment');
                                                if (found) {
                                                    found.removeClass("selected_treatment");
                                                }
                                                $('#treat_' + categ_no + '_' + each_treatment.treatment_id).attr('class', 'selected_treatment');
                                                selected_treatment = each_treatment;
                                                found_selected_tooth.forEach(function(each_found_selected_tooth) {
                                                // _.each(found_selected_tooth, function(each_found_selected_tooth) {
                                                    selected_tooth = each_found_selected_tooth.id;
                                                    console.log("selected_tooth{{{{{{{{{{{{{{{{{{{{{{", selected_tooth)
                                                    selected_surface.length = 0;
                                                    if($("#" +'view_' + selected_tooth + '_top').attr('fill') == 'orange'){
                                                        selected_surface.push('view_' + selected_tooth + '_top');
                                                    }
                                                    if($("#" +'view_' + selected_tooth + '_bottom').attr('fill') == 'orange'){
                                                        selected_surface.push('view_' + selected_tooth + '_bottom');
                                                    }
                                                    if($("#" +'view_' + selected_tooth + '_center').attr('fill') == 'orange'){
                                                        selected_surface.push('view_' + selected_tooth + '_center');
                                                    }
                                                    if($("#" +'view_' + selected_tooth + '_right').attr('fill') == 'orange'){
                                                        selected_surface.push('view_' + selected_tooth + '_right');
                                                    }
                                                    if($("#" +'view_' + selected_tooth + '_left').attr('fill') == 'orange'){
                                                        selected_surface.push('view_' + selected_tooth + '_left');
                                                    }
                                                    if (each_treatment.action == 'missing') {
                                                        Missing_Tooth.push(parseInt(selected_tooth));
                                                        self.perform_missing_action([selected_tooth]);
                                                    }
                                                    self.execute_create(true, self, false);
                                                    $(each_found_selected_tooth).removeClass('selected_tooth');
                                                });
                                                selected_surface.length = 0;
                                            }
                                        }
                                        if (!found_selected_tooth[0] && !selected_surface[0]) {
                                            alert('Please select the surface first!');
                                            return;
                                        }
                                        $('#' + this.id).removeClass('selected_treatment');
                                        selected_treatment = '';
                                    });
                                });
                                break;
                            }
                            console.log("Outside if")
                        }
                    } else {
                        alert('Select a tooth first!!');
                    }
                });
            }
        } catch (err) {
            console.error(err);
        }
    }

    async getTreatmentCharge(treatmentId) {
        const res = await this.orm.call('product.product', 'get_treatment_charge', [treatmentId], {});
        return res;
    }
    

    async decrementThread(selectedSurf) {
        selectedSurf.forEach(ss => {
            const prevCnt = document.getElementById(ss).classList[3];
            const newCnt = String(parseInt(prevCnt) - 1);
            document.getElementById(ss).classList.remove(prevCnt);
            document.getElementById(ss).classList.add(newCnt);
        });
    }
    
    incrementThread(selectedSurf) {
        selectedSurf.forEach(ss => {
            const prevCnt = document.getElementById(ss).classList[3];
            const newCnt = String(parseInt(prevCnt) + 1);
            document.getElementById(ss).classList.remove(prevCnt);
            document.getElementById(ss).classList.add(newCnt);
        });
    }

    async checkIfToothPresent(toothId) {
        console.log("--------checkIfToothPresent-------",toothId)
        var treatment_lines = new Array();
        for (var i = 0; i < treatment_lines.length; i++) {
            if (treatment_lines[i]['tooth_id'] == tooth_id) {
                return 1;
            }
        }
        return 0;    
    }

    async putDataFullMouth(selfVar, fullMouthTeethTemp, fullMouth, selectedTreatmentTemp, statusToDefine, createdDate, isPrevRecord, otherHistory) {
        if (selectedTreatmentTemp.action === 'missing') {
            await selfVar.performMissingAction(fullMouthTeethTemp);
        }
        if (fullMouth) {
            const plannedText = $('#planned').text().trim();
            let statusToDefineTemp = plannedText;
            const completedText = $('#completed').text().trim();
            const inProgressText = $('#in_progress').text().trim();
            const statusDefined = statusToDefineTemp.toLowerCase();
            if (statusToDefine) {
                if (statusToDefine === 'completed') {
                    statusToDefineTemp = completedText;
                } else if (statusToDefine === 'in_progress') {
                    statusToDefineTemp = inProgressText;
                } else if (statusToDefine === 'planned') {
                    statusToDefineTemp = plannedText;
                }
            }
            const today = new Date();
            if (createdDate) {
                today = createdDate;
            }
            let tableStr = '';
            try {
                const tCharge = await selfVar.getTreatmentCharge(selectedTreatmentTemp.treatment_id);
                if (!tCharge) {
                    tCharge = '0.0';
                }
                operationId += 1;
                let totalTeeth = '';
                const surfList = [];
                fullMouthTeethTemp.forEach(eachFullMouthTeethTemp => {
                    totalTeeth += `_${eachFullMouthTeethTemp}`;
                    surfList.push(`view_${eachFullMouthTeethTemp}_center`);
                    surfList.push(`view_${eachFullMouthTeethTemp}_right`);
                    surfList.push(`view_${eachFullMouthTeethTemp}_left`);
                    surfList.push(`view_${eachFullMouthTeethTemp}_top`);
                    surfList.push(`view_${eachFullMouthTeethTemp}_bottom`);
                });
                selfVar.incrementThread(surfList);
                totalTeeth = totalTeeth.substr(1);
                if (otherHistory) {
                    tableStr += `<tr class=${totalTeeth} id=operation_${operationId} style="display:none">`;
                } else {
                    tableStr += `<tr class=${totalTeeth} id=operation_${operationId}>`;
                }
                tableStr += `<td id=date_time_${operationId}>${today}</td>`;
                tableStr += `<td class=${selectedTreatmentTemp.treatment_id} id=desc_${operationId}>${selectedTreatmentTemp.treatment_name}</td>`;
                tableStr += `<td class="all" id=tooth_${operationId}>-</td>`;
                tableStr += `<td id=status_${operationId} status_name=${statusToDefine}>${statusToDefineTemp}</td>`;
                tableStr += `<td id=surface_${operationId}>Full Mouth</td>`;
                tableStr += `<td id=dentist_${operationId}>${userName}</td>`;
                tableStr += `<td id=amount_${operationId}>${tCharge}</td>`;
                tableStr += `<td class=progress_table_actions id=action_${operationId}>${selectedTreatmentTemp.action}</td>`;
                tableStr += `<td class=delete_td id=delete_${operationId}><img src=/pragtech_dental_management/static/src/img/delete.png height=20px width=20px/></td>`;
                tableStr += `<td style=display:none id=previous_${operationId}>${isPrevRecord}</td>`;
                tableStr += '</tr>';
                let htmlTableData = '';
                let bRowStarted = true;
                $('#operations tbody>tr').each(function () {
                    $('td', this).each(function () {
                        if (htmlTableData.length === 0 || bRowStarted === true) {
                            htmlTableData += $(this).text();
                            bRowStarted = false;
                        } else {
                            htmlTableData += ` | ${$(this).text()}`;
                        }
                    });
                    htmlTableData += '\n';
                    bRowStarted = true;
                });
                let flag = false;
                htmlTableData.split('\n').forEach(nameTreatment => {
                    const description = nameTreatment.split('|')[1].trim();
                    const str1 = `${description}`;
                    const str2 = `${selectedTreatmentTemp.treatment_name.trim()}`;
                    if (str1 === str2) {
                        flag = true;
                    }
                });
                if (!flag) {
                    $('#progres_table').append(tableStr);
                    $(`#delete_${operationId}`).click(function () {
                        const x = window.confirm('Are you sure you want to delete?');
                        if (x) {
                            update = false;
                            cont = false;
                            const actualId = parseInt(this.id.substr(7));
                            const tr = document.getElementById(`operation_${actualId}`);
                            const tooth = document.getElementById(`tooth_${actualId}`);
                            const descClass = $(`#desc_${actualId}`).attr('class');
                            const toothId = tr.className.split('_');
                            const status = document.getElementById(`status_${actualId}`);
                            const statusName = $(status).attr('status_name');
                            if (statusName === 'completed' || statusName === 'in_progress') {
                                alert('Cannot delete');
                            } else {
                                const action = document.getElementById(`action_${actualId}`);
                                const actionId = action.innerHTML;
                                const surfList = [];
                                fullMouthTeethTemp.forEach(toothId => {
                                    surfList.push(`view_${toothId}_center`);
                                    surfList.push(`view_${toothId}_right`);
                                    surfList.push(`view_${toothId}_left`);
                                    surfList.push(`view_${toothId}_top`);
                                    surfList.push(`view_${toothId}_bottom`);
                                });
                                selfVar.decrementThread(surfList);
                                selfVar.removeSelectionAction(toothId);
                                if (actionId === 'missing') {
                                    selfVar.removeMissingAction(toothId);
                                }
                                tr.parentNode.removeChild(tr);
                            }
                        }
                    });
                }
                $(`#operation_${operationId}`).click(function () {
                    const found = selfVar.$el.find('.selected_operation');
                    if (found) {
                        found.removeClass('selected_operation');
                    }
                    $(this).attr('class', 'selected_operation');
                });
            } catch (error) {
                console.error('An error occurred:', error);
            }
        }
    }

    async putData(selfVar, surfaces, selectedToothTemp, selectedSurfaceTemp, statusDefined, createdDate, isPrevRecord, otherHistory) {
        if (!selectedToothTemp) {
            selectedToothTemp = '-';
        }
        const selectedTreatmentTemp = selectedTreatment;
        let tableStr = '';
        let today = new Date();
        if (createdDate) {
            today = createdDate;
        }
        const pannedText = $('#planned').text().trim();
        let statusToUse = pannedText;
        const completedText = $('#completed').text().trim();
        const inProgressText = $('#in_progress').text().trim();
        if (statusDefined) {
            if (statusDefined === 'completed') {
                statusToUse = completedText;
            } else if (statusDefined === 'in_progress') {
                statusToUse = inProgressText;
            } else if (statusDefined === 'planned') {
                statusToUse = pannedText;
            }
        }
        if (statusToUse === 'planned') {
            statusToUse = pannedText;
        }
    
        // Assuming get_treatment_charge is defined somewhere
        const tCharge = get_treatment_charge(selectedTreatmentTemp.treatment_id) || '0.0';
    
        operationId += 1;
        const found = selfVar.$el.find('.selected_operation');
        if (found) {
            found.removeClass("selected_operation");
        }
    
        let displayStyle = '';
        if (otherHistory) {
            displayStyle = 'style= "display:none"';
        }
        
        tableStr += `<tr id="operation_${operationId}" ${displayStyle}>`;
        tableStr += `<td id="date_time_${operationId}">${today}</td>`;
        tableStr += `<td class="${selectedTreatmentTemp.treatment_id}" id="desc_${operationId}">${selectedTreatmentTemp.treatment_name}</td>`;
    
        if (type == 'palmer') {
            const numbers = parseInt(selectedToothTemp);
            if (selectedToothTemp === '-') 
            {
                tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${numbers}</td>`;
            } 
            switch (numbers) {
                case 1:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[1]}</td>`;
                    break;
                case 2:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[2]}</td>`;
                    break;
                case 3:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[3]}</td>`;
                    break;
                case 4:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[4]}</td>`;
                    break;
                case 5:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[5]}</td>`;
                    break;
                case 6:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[6]}</td>`;
                    break;
                case 7:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[7]}</td>`;
                    break;
                case 8:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[8]}</td>`;
                    break;
                case 9:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[9]}</td>`;
                    break;
                case 10:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[10]}</td>`;
                    break;
                case 11:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[11]}</td>`;
                    break;
                case 12:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[12]}</td>`;
                    break;
                case 13:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[13]}</td>`;
                    break;
                case 14:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[14]}</td>`;
                    break;
                case 15:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[15]}</td>`;
                    break;
                case 16:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[16]}</td>`;
                    break;
                case 17:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[17]}</td>`;
                    break;
                case 18:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[18]}</td>`;
                    break;
                case 19:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[19]}</td>`;
                    break;
                case 20:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[20]}</td>`;
                    break;
                case 21:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[21]}</td>`;
                    break;
                case 22:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[22]}</td>`;
                    break;
                case 23:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[23]}</td>`;
                    break;
                case 24:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[24]}</td>`;
                    break;
                case 25:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[25]}</td>`;
                    break;
                case 26:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[26]}</td>`;
                    break;
                case 27:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[27]}</td>`;
                    break;
                case 28:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[28]}</td>`;
                    break;
                case 29:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[29]}</td>`;
                    break;
                case 30:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[30]}</td>`;
                    break;
                case 31:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[31]}</td>`;
                    break;
                case 32:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Palmer[32]}</td>`;
                    break;
                case '-':
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${'-'}</td>`;
                    break;
            }
        }else if (type == 'universal') {
            table_str += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${selectedToothTemp}</td>`
        }
        else if (type == 'iso') 
        {
            var numbers = parseInt(selectedToothTemp);
            switch (numbers) {
                case 1:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[1]}</td>`;
                    break;
                case 2:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[2]}</td>`;
                    break;
                case 3:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[3]}</td>`;
                    break;
                case 4:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[4]}</td>`;
                    break;
                case 5:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[5]}</td>`;
                    break;
                case 6:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[6]}</td>`;
                    break;
                case 7:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[7]}</td>`;
                    break;
                case 8:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[8]}</td>`;
                    break;
                case 9:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[9]}</td>`;
                    break;
                case 10:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[10]}</td>`;
                    break;
                case 11:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[11]}</td>`;
                    break;
                case 12:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[12]}</td>`;
                    break;
                case 13:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[13]}</td>`;
                    break;
                case 14:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[14]}</td>`;
                    break;
                case 15:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[15]}</td>`;
                    break;
                case 16:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[16]}</td>`;
                    break;
                case 17:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[17]}</td>`;
                    break;
                case 18:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[18]}</td>`;
                    break;
                case 19:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[19]}</td>`;
                    break;
                case 20:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[20]}</td>`;
                    break;
                case 21:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[21]}</td>`;
                    break;
                case 22:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[22]}</td>`;
                    break;
                case 23:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[23]}</td>`;
                    break;
                case 24:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[24]}</td>`;
                    break;
                case 25:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[25]}</td>`;
                    break;
                case 26:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[26]}</td>`;
                    break;
                case 27:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[27]}</td>`;
                    break;
                case 28:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[28]}</td>`;
                    break;
                case 29:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[29]}</td>`;
                    break;
                case 30:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[30]}</td>`;
                    break;
                case 31:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[31]}</td>`;
                    break;
                case 32:
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${Iso[32]}</td>`;
                    break;
                case '-':
                    tableStr += `<td class="${selectedToothTemp}" id="tooth_${operationId}">${'-'}</td>`;
                    break;
                }
            }
                
        tableStr += `<td id="status_${operationId}" status_name="${statusDefined}">${statusToUse}</td>`;
        tableStr += '<td id="surface_${operationId}">';
        surfaces.forEach(eachSurf => {
            tableStr += `${eachSurf} `;
        });
        selfVar.incrementThread(selectedSurfaceTemp);
        tableStr += '</td>';
        tableStr += `<td id="dentist_${operationId}">${userName}</td>`;
        tableStr += `<td id="amount_${operationId}">${tCharge}</td>`;
        tableStr += `<td class="progress_table_actions" id="action_${operationId}">${selectedTreatmentTemp.action}</td>`;
        tableStr += `<td class="delete_td" id="delete_${operationId}"><img src="/pragtech_dental_management/static/src/img/delete.png" height="20px" width="20px"/></td>`;
        tableStr += `<td style="display:none" id="previous_${operationId}">${isPrevRecord}</td>`;
        tableStr += '</tr>';
    
        $('#progres_table').append(tableStr);
    
        $(`#operation_${operationId}`).click(function () {
            const found = selfVar.$el.find('.selected_operation');
            if (found) {
                found.removeClass("selected_operation");
            }
            $(this).attr('class', 'selected_operation');
        });
    
        $(`#delete_${operationId}`).click(function () {
            const x = window.confirm("Are you sure you want to delete?");
            if (x) {
                update = false;
                cont = false;
                const actualId = String(this.id).substr(7);
                const actualIdInt = parseInt(actualId);
                const tabel = document.getElementById('operations');
                const tr = document.getElementById(`operation_${actualIdInt}`);
                const tooth = document.getElementById(`tooth_${actualIdInt}`);
                const descClass = $(`#desc_${actualIdInt}`).attr('class');
                const toothId = $(tooth).attr('class');
                const status = document.getElementById(`status_${actualIdInt}`);
                const statusName = $(status).attr('status_name');
                
                if (statusName === 'completed' || statusName === 'in_progress') {
                    alert('Cannot delete');
                } else {
                    const action = document.getElementById(`action_${actualIdInt}`);
                    const actionId = action.innerHTML;
                    
                    if (actionId === 'missing') {
                        const surfaceVals = ($(`#surface_${actualIdInt}`).text()).split(' ');
                        const surfList = [];
                        surfaceVals.forEach(sv => {
                            if ($(`#view_${toothId}_center`).attr('class').split(' ')[1] === sv) {
                                surfList.push(`view_${toothId}_center`);
                            }
                            if ($(`#view_${toothId}_right`).attr('class').split(' ')[1] === sv) {
                                surfList.push(`view_${toothId}_right`);
                            }
                            if ($(`#view_${toothId}_left`).attr('class').split(' ')[1] === sv) {
                                surfList.push(`view_${toothId}_left`);
                            }
                            if ($(`#view_${toothId}_top`).attr('class').split(' ')[1] === sv) {
                                surfList.push(`view_${toothId}_top`);
                            }
                            if ($(`#view_${toothId}_bottom`).attr('class').split(' ')[1] === sv) {
                                surfList.push(`view_${toothId}_bottom`);
                            }
                        });
                        selfVar.decrementThread(surfList);
                    }
                    
                    tr.parentNode.removeChild(tr);
                    
                    for (let index = 0; index < treatmentLines.length; index++) {
                        if (treatmentLines[index].tooth_id === toothId) {
                            for (let i2 = 0; i2 < treatmentLines[index].treatments.length; i2++) {
                                if (treatmentLines[index].treatments[i2].treatment_id === parseInt(descClass)) {
                                    treatmentLines.splice(index, 1);
                                    operationId += 1;
                                    const found = selfVar.$el.find('.selected_treatment_temp');
                                    if (found) {
                                        found.removeClass("selected_treatment_temp");
                                    }
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        });
    }

    async writePatientHistory(selfVar, res) {
        let isPrevRecordFromWrite = false;
    
        for (const eachOperation of res) {
            const selectedTreatment = {
                'treatmentId': eachOperation['desc']['id'],
                'treatmentName': eachOperation['desc']['name'],
                'action': eachOperation['desc']['action']
            };
    
            console.log('selectedTreatment', selectedTreatment);
    
            isPrevRecordFromWrite = false;
    
            if (eachOperation['status'] === 'completed') {
                isPrevRecordFromWrite = true;
            }
    
            if (eachOperation['status'] === 'in_progress') {
                eachOperation['status'] = 'in_progress';
            }
    
            if (eachOperation['tooth_id']) {
                console.log("Progress 111");
                await selfVar.putData(selfVar, eachOperation['surface'].split(' '), eachOperation['tooth_id'], false, eachOperation['status'], eachOperation['created_date'], isPrevRecordFromWrite, eachOperation['other_history']);
            } else {
                await selfVar.putDataFullMouth(selfVar, eachOperation.multiple_teeth, 1, selectedTreatment, eachOperation['status'], eachOperation['created_date'], isPrevRecordFromWrite, eachOperation['other_history']);
            }
        }
    
        selectedTreatment = '';
    }

    async execute_create(attrs, selfVar, selected_surface_temp) {
        console.log("--------called execute_create method-------",attrs, selfVar, selected_surface_temp)
        if (!selected_surface_temp) {
            selected_surface_temp = selected_surface;
        }
        console.log("thiiiiiiiiiiiiiiiiiiiiiiiisssssssss", this)
        var selected_tooth = "";
        var dentist_id = ''
        selected_tooth = 1
        var tooth_present = this.checkIfToothPresent(selected_tooth);
        var record = new Array();
        var treatment_lines = new Array();

        record['treatments'] = new Array();
        record['tooth_id'] = selected_tooth;
        record['dentist'] = dentist_id;
        var surfaces = new Array();
        selected_surface_temp.forEach(function(each_surface) {
            var surface = $('#' + each_surface).attr('class').split(' ')[1];
            surfaces.push(surface);
        });
        var d = new Array();
        d = {
            'treatment_id' : selected_treatment['treatment_id'],
            'vals' : surfaces
        };
        var selected_tooth_temp = selected_tooth;
        if (attrs) {
            if (!tooth_present) {
                record['treatments'].push(d);
                treatment_lines.push(record);
                this.put_data(selfVar, surfaces, selected_tooth_temp, selected_surface_temp, 'planned', false, false, false);
            } else {
                var treatment_present = 0;
                for (var i = 0; i < treatment_lines.length; i++) {
                    if (treatment_lines[i]['tooth_id'] == parseInt(selected_tooth_temp)) {
                        for (var each_trts = 0; each_trts < treatment_lines[i]['treatments'].length; each_trts++) {
                            if (treatment_lines[i]['treatments'][each_trts].treatment_id == selected_treatment['treatment_id']) {
                                treatment_present = 1;
                                break;
                            }
                        }
                        if (!treatment_present) {
                            var x = treatment_lines;
                            treatment_lines[i]['treatments'].push(d);
                            this.put_data(selfVar, surfaces, selected_tooth_temp, selected_surface_temp, false, false, false, false);
                        }
                    }
                }

            }
        } else {
            if (!tooth_present) {
                record['treatments'].push(d);
                treatment_lines.push(record);
                surfaces.length = 0;
                this.put_data(selfVar, surfaces, selected_tooth_temp, false, false, false, false);
            } else {

            }
        }
    }
    
}


DentalChartAction.template = "pragtech_dental_management.DentalAction";

registry
    .category("actions")
    .add("dental_chart", DentalChartAction, { force: true });
